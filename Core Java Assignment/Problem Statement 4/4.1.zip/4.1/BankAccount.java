package ProblemStatement;

public class BankAccount {
	int account_number;
    String name;
    String account_type;
    double balance;
   
    public int getAccount_number() {
        return account_number;
    }
   
    public void setAccount_number(int account_number) {
        this.account_number = account_number;
    }
   
    public String getName() {
        return name;
    }
   
    public void setName(String name) {
        this.name = name;
    }
   
    public String getAccount_type() {
        return account_type;
    }
   
    public void setAccount_type(String account_type) {
        this.account_type = account_type;
    }
   
    public double getBalance() {
    	
    	if (account_type == "savings") {       
	        if( balance <1000)
	        {
		        try
		        {   
		            throw new NumberFormatException();
		        }
		        catch(NumberFormatException nw)
		        {
		            System.out.println("InsufficientFunds"+balance);
		        }
	        }       
    	}
    	else if (account_type == "current") {       
	        if( balance <5000)
	        {
		        try
		        {   
		            throw new NumberFormatException();
		        }
		        catch(NumberFormatException nw)
		        {
		            System.out.println("InsufficientFunds"+balance);
		        }
	        }       
    	}
    	return balance;
       
    }
    public void setBalance(double balance) {
        this.balance = balance;
    }

    public BankAccount() {
       
        this.account_number = 100;
        this.name = "Vicky";
        this.account_type = "savings";
        this.balance = 500;
        
        this.account_number = 200;
        this.name = "Vishal";
        this.account_type = "current";
        this.balance = 4500;
    }

    public BankAccount(int account_number, String name, String account_type, double balance) {
       
        this.account_number = account_number;
        this.name = name;
        this.account_type = account_type;
        this.balance = balance;
    }
    void deposit(double amt)
    {
        if(amt<0)
        {
            try
            {
                throw new NumberFormatException();
            }
            catch(NumberFormatException nf)
            {
                System.out.println("NEGATIVE AMOUNT CANNOT BE DIPOSITED");
            }
        }
        else
        {
            balance=getBalance()+amt;
            System.out.println("Current balance is ="+balance);
           
        }
       
    }
     public void withdraw(double amt){
         if(amt>balance)
            {
                try
                {
                    throw new NumberFormatException();
                }
                catch(NumberFormatException nf)
                {
                    System.out.println("AMOUNT CANNOT BE WIDTHDRAWN, INSUFFICENT BALANCE ");
                }
            }
            else
            {
                balance=getBalance()-amt;
                System.out.println("Current balance is ="+balance);
               
            }

    }
     void display()
     {
    	 System.out.println("Balance is ="+getBalance());   
     }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BankAccount b=new BankAccount();
        b.deposit(2000);
        b.display();
        b.deposit(-1000);
        b.display();
        b.withdraw(500);
        b.display();
        b.withdraw(2500);
        b.getBalance();
        b.display();
       
	}

}
