package ProblemStatement;

public class ArrayOP {

	public static void main(String[] args) {
		int sum=0,avg,temp;
        int[] array=new int[] {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};
          for (int i = 0; i < array.length; i++) {  
               sum = sum + array[i];  
            }  
          System.out.println("Sum of all the elements of an array: " + sum);  
          
          avg=sum/array.length;
          array[15]=sum;
          
          System.out.println("Average of all the elements of an array: " + avg);
          array[16]=avg;
          
          for(int i=0;i<array.length;i++) {
              for(int j=i+1;j<array.length;j++) {
                  if(array[i]>array[j]) {
                      temp=array[i];
                      array[i]=array[j];
                      array[j]=temp;
                  }
              }
          }

          System.out.println("smallest number"+array[0]);
          array[17]=array[0];
          for(int i=0;i<array.length;i++) {
              System.out.println(array[i]);
          }
	}

}
