package ProblemStatement;

public class StringManipulate {
public static void main(String[] args) {
			
		
		String txt= "JAVA is Simple";
		
		System.out.println(txt.toUpperCase());
		
		System.out.println(txt.toLowerCase());
		
		
		String[] s1=txt.split("\\s");	//1st letter of each word
		for(String w:s1){  
			System.out.print(w.charAt(0)); 
			System.out.print(" ");
		}
		System.out.println(" ");		
		
		String[] s2=txt.split("\\s"); // Change order of words
		String ord = ""; 
	      for (int i = s2.length - 1; i >= 0; i--) { 
	        ord += s2[i] + " "; 
	      } 
	      System.out.println("Reversed String: " + ord); 
		System.out.println(" ");
		
		StringBuilder s3= new StringBuilder("JAVA is Simple");//string reversal

		System.out.println("String = " + s3.toString());
		StringBuilder reverseStr = s3.reverse();
		System.out.println("Reverse String = " + reverseStr.toString());
		
		String[] s4 = txt.split(" ");
        int length = txt.length();
		System.out.println("length of string " +length);//length of string
	}

}
