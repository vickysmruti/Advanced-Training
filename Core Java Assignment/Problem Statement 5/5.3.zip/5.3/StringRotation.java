package ProblemStatement;

public class StringRotation {
	public static void ShowString(String str)
    {
        int len = str.length();

        StringBuffer sb;
         
        for (int i = 0; i < len+1; i++)
        {
            sb = new StringBuffer();
             
            int j = i; 
            int k = 0;  
      
            for (int l = j; l < str.length(); l++) {
                sb.insert(k, str.charAt(j));
                k++;
                j++;
            }

            j = 0;
            while (j < i)
            {
                sb.insert(k, str.charAt(j));
                j++;
                k++;
            }
      
            System.out.println(sb);
        }
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String  str = new String("MPHASIS");
        ShowString(str);
	}

}
