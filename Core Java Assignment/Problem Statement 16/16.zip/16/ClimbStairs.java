package problemStatement2;

import java.util.Scanner;

public class ClimbStairs {
	public static int totalWays(int n)
    {

        if (n < 0) {
            return 0;
        }

        if (n == 0) {
            return 1;
        }
 
        return totalWays(n - 1) + totalWays(n - 2);
    }
 
    public static void main(String[] args)
    {
    	Scanner scanner=new Scanner(System.in);
 	    System.out.println("Enter the Number of Stairs : ");
 	    int n=scanner.nextInt();
 	    
        System.out.printf("Total ways to reach the %d'th stair are %d", n, totalWays(n));
    }

}
