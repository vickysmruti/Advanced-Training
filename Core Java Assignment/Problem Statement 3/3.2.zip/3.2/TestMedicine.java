package ProblemStatement;

interface MedicineInfo{
	static void displayLabel(){
		System.out.println("Company : Emcure Pharma");
		System.out.println("Address : Pune");
	}
}
class Tablet implements MedicineInfo{
	 static void displayLabel(){
		 System.out.println("Tablets need to be stored in a cool dry place");
	}
}
class Syrup implements MedicineInfo{
	static void displayLabel(){
	System.out.println("Use Syrup as directed by the physician");
	}
	}
class Ointment implements MedicineInfo{
	static void displayLabel(){
	System.out.println("Ointments are for external use only");
}
}

public class TestMedicine {

	public static void main(String[] args) {
		MedicineInfo m[] = new MedicineInfo[10];
		double i = 1 + (int)(Math.random() * 3);
		int j = (int) i;
		System.out.println(j);
		switch(j){		
		
			case 1: 
//			m[0] = new MedicineInfo();
//			m[1] = new Tablet();
			MedicineInfo.displayLabel();
			Tablet.displayLabel();
			break;
		
			case 2:
//			m[2] = new MedicineInfo();
//			m[3] = new Syrup();
			MedicineInfo.displayLabel();
			Syrup.displayLabel();
			break;
		
			case 3:
//			m[4] = new MedicineInfo();
//			m[5] = new Ointment();
			MedicineInfo.displayLabel();
			Ointment.displayLabel();
			break;
		
			default: System.out.println("Invalid Choice");
	}

	}

}
