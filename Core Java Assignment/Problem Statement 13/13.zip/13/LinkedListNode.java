package problemStatement2;

public class LinkedListNode {
	Node head; 
	class Node 
	{
		int data;
		Node next;
		Node(int d)
		{
			data = d;
			next = null;
		}
	}
	void printNode(int n)
	{
		int len = 0;
		Node temp = head;
	    while (temp != null) 
	    {
			temp = temp.next;
			len++;
		}
		if (len < n)
			return;
		temp = head;
		for (int i = 1; i < len - n + 1; i++)
			temp = temp.next;
		System.out.println(n+"th node from the end is "+temp.data);
	}
	public void add(int newData)
	{
		Node newNode = new Node(newData);
		newNode.next = head;
		head = newNode;
	}
		

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedListNode ll = new LinkedListNode();
		ll.add(1);
		ll.add(2);
		ll.add(3);
		ll.add(4);
        ll.add(5);
        ll.add(6);
        ll.add(7);
        ll.add(8);
        ll.add(9);
		ll.printNode(6);

	}

}
