package problemStatement2;

import java.util.HashMap;

public class RepeatingDecimal {
	public static String fractionToDecimal(int numerator, int denominator) {
        if (numerator == 0) {
            return "0";
        }
        StringBuilder res = new StringBuilder();
        res.append(((numerator > 0) ^ (denominator > 0)) ? "-" : "");
        long num = Math.abs((long)numerator);
        long den = Math.abs((long)denominator);

        res.append(num / den);
        num %= den;
        if (num == 0) {
            return res.toString();
        }

        res.append(".");
        HashMap<Long, Integer> map = new HashMap<Long, Integer>();
        map.put(num, res.length());
        while (num != 0) {
            num *= 10;
            res.append(num / den);
            num %= den;
            if (map.containsKey(num)) {
                int index = map.get(num);
                res.insert(index, "(");
                res.append(")");
                break;
            }
            else {
                map.put(num, res.length());
            }
        }
        return res.toString();
    }

	public static void main(String[] args) {
		
		int num = 1;
		int den = 3;
		String resString1 = fractionToDecimal(num, den);

		num = 1;
		den = 4;
		String resString2 = fractionToDecimal(num, den);
		
		num = 1;
		den = 6;
		String resString3 = fractionToDecimal(num, den);
		
		num = 1;
		den = 7;
		String resString4 = fractionToDecimal(num, den);

		System.out.println(resString1);
		System.out.println(resString2);
		System.out.println(resString3);
		System.out.println(resString4);

	}

}
