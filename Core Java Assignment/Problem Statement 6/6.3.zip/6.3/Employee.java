package ProblemStatement;

import java.util.Vector;

public class Employee {
	private int empid;
	private String  ename, address;
	
	public Employee (int empid, String ename, String address) {
		
		super();
		this.empid=empid;
		this.ename=ename;
		this.address=address;
	}
	
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	
	private static final Employee[] v = null;
	public static void main(String[] args) {
		Vector<Employee> v= addInput();
		display(v);
	}
	private static Vector<Employee> addInput() {
		
		return null;
	}
	private static void display(Vector<Employee> v) {
		
	}
	
	public static Vector<Employee> main1() {
		
		Employee e1=new Employee(101, "nagesh", "ganesh");
		Employee e2=new Employee(102, "nichitha", "gopal");
		Employee e3=new Employee(103, "mallesh", "mahesh");
		Vector<Employee> v=new Vector<Employee>();
		v.add(e1);
		v.add(e2);
		v.add(e3);
		return v;
		
	}
	public static void main1(String[] args) {
		
		for (Employee e :v) {
			System.out.println(e.getEmpid()+"\t"+e.getEname()+"\t"+e.getAddress());
			
		}
	}

}
